DOMINICAN CEDULA CERTIFICATE BUNDLE
===================================

Scope: Certificates embedded in saved files read from an authorized card.

This archive contains TWO distinct X.509 certificates. Each certificate is provided
twice, once as PEM text and once as binary DER. The PEM and DER files are alternate
encodings of the same certificate; there are not four different certificates.

No private key is present in this bundle. X.509 certificates contain public keys and
descriptive/signature metadata only. A certificate must not be treated as a trust
anchor merely because it was embedded in a card object.


1. jce-ds-02.pem / jce-ds-02.der
--------------------------------

Card source:
  EF.SOD, embedded CMS Document Signer certificate.

Subject:
  C=DO, O=Junta Central Electoral - JCE, OU=DOM, CN=JCE DS 02

Issuer named by certificate:
  C=DO, O=Junta Central Electoral - JCE, CN=JCE CSCA

Serial number:
  199686BB721AD7689CB5

Certificate SHA-256 fingerprint:
  1412267945fdd2d6d196bcc49acff007dd91f61de761b8ab7e0e16bcf327dfb5

Subject Key Identifier:
  f4047b2a821fea2b8c537f474a274f2a97d0460f

Authority Key Identifier:
  e8090eb7d5c71ffe568f0654a4675af5ea264bb8

Public key:
  Elliptic-curve key encoded with explicit parameters. The exact parameters match
  BrainpoolP256r1. SPKI SHA-256:
  1668370ca5f4a0625159d5334d8202b7b27d4220e4139eb02a4d22c8043beef3

Certificate validity:
  2026-04-17 20:35:41 UTC through 2036-08-17 20:35:41 UTC

Private-key usage period declared by certificate:
  2026-04-17 20:35:41 UTC through 2026-08-17 20:35:41 UTC

Observed purpose:
  This is the Document Signer certificate used to verify the signature over the LDS
  Security Object in EF.SOD. That signed object commits to SHA-256 hashes of DG1,
  DG2, DG3, DG7, DG11, DG12, DG13, and DG14. Every acquired signed DG matched.
  The ICAO Document Type List extension identifies document type "I" (identity card).

Verification status:
  The EF.SOD CMS signature verifies under this public key with OpenSSL and with an
  independent local DER/ECDSA implementation. External trust remains unresolved
  because the matching JCE CSCA certificate and applicable CRL have not been found.
  The unrelated Dominican passport CSCA does not match this certificate's issuer/AKI.

Encoding note:
  The certificate's outer ECDSA-with-SHA384 AlgorithmIdentifier and the observed
  EF.SOD ECDSA-with-SHA256 AlgorithmIdentifier contain NULL parameters. This is an
  invalid ECDSA AlgorithmIdentifier encoding that current tools accepted with a
  warning, but stricter future parsers may reject it.


2. cardsecurity-development-ds.pem / cardsecurity-development-ds.der
---------------------------------------------------------------------

Card source:
  EF.CardSecurity, embedded CMS signer certificate.

Subject:
  C=DE, O=cryptovision, OU=development, CN=DS

Issuer named by certificate:
  C=DE, O=cryptovision, OU=development, CN=CSCA

Serial number:
  7001220488CDEFEA33B26B059A28637C

Certificate SHA-256 fingerprint:
  4eb27936eeee488c8409044d8db3ff22210155443b89db7e4b21aee2f95704e2

Authority Key Identifier:
  641f978a63ae1b407174e96e3566af347fed3b20

Public key:
  RSA, 1024 bits. SPKI SHA-256:
  ec77a452c2c5f0b54c2c106c665301eac245cc596e8614e62448365fcafbaabc

Certificate validity:
  2019-12-31 23:00:00 UTC through 2079-12-31 23:00:00 UTC

Observed purpose:
  This certificate signs EF.CardSecurity. Its signed content is the same 22-byte
  PACE capability declaration found in EF.CardAccess: PACE ECDH-GM with AES-256
  CBC-CMAC, version 2, standardized parameter identifier 15. The declaration is
  protocol metadata, not a card public or private key.

Observed CMS signing time:
  2026-02-04 11:44:47 UTC

Verification status:
  The EF.CardSecurity CMS signature verifies under this public key with OpenSSL and
  an independent local DER/RSA modular-arithmetic implementation. Its external chain
  remains unresolved because the named Cryptovision development CSCA was not supplied.
  The development signer belongs to the CardSecurity/EAC trust domain; it cannot be
  substituted for the JCE EF.SOD Document Signer or JCE CSCA.

Security note:
  RSA-1024 and a development-labelled certificate are legacy/development properties.
  Mathematical signature validity does not establish that this certificate is an
  externally approved production trust anchor.


FILES NOT INCLUDED
==================

dominican-republic-icao-masterlist-csca.pem was not included. It was extracted from
an external ICAO Master List, not from the cedula. It is a Dominican passport CSCA
and does not validate either embedded certificate in this archive.

No citizen-signature certificate was found in the card's PKCS#15 certificate
directories; those observed directories were zero-filled. Therefore this archive
does not contain a citizen signing certificate.


QUICK INSPECTION
================

PEM:
  openssl x509 -in jce-ds-02.pem -noout -text
  openssl x509 -in cardsecurity-development-ds.pem -noout -text

DER:
  openssl x509 -inform DER -in jce-ds-02.der -noout -text
  openssl x509 -inform DER -in cardsecurity-development-ds.der -noout -text

Integrity:
  sha256sum -c SHA256SUMS

See the repository's lab/PASSIVE_AUTHENTICATION_ANALYSIS.md and
lab/CARDSECURITY_PASSIVE_AUTH_ANALYSIS.md for the supporting audit results.
